<?php
class Question extends Controller
{

    function __construct()
    {
        $this->folder_view = "add_question";
        $this->layout = "default";
    }
    function __construct()
    {
        $this->tableName = "question";
    }

    public function add($objet)
    {
        $sql = "INSERT INTO `question` (`id`, `description`, `nbrePoints`) VALUES (NULL , '" . $objet->description . "', '" . $objet->nbrePoints . "');";
        return  $this->executeUpdate($sql) != 0;
    }
    public function update($objet)
    {
    }

    public function findById($id)
    {
    }
}
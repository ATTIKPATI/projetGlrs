<?php

class Question
{
    //Attributs
    public $id;
    public $description;
    public $nbrePoints;
    public $typeReponseId;



    public function __construct($rowBd = null)
    {

        if ($rowBd != null) {
            $this->id = $rowBd['id'];
            $this->login = $rowBd['description'];
            $this->password = $rowBd['nbrePoints'];
        }
    }

    public function getQuestion()
    {
        return $this->question;
    }
}

<?php
class Question extends Controller{

    function __construct(){
        $this->folder_view="question";
        $this->layout="default";

    }

    
}




<?php
   define("URL_ASSETS","http://localhost/projet/quizzs/assets");
   define("URL_ROOT","http://localhost/projet/quizzs");
  require_once('./libs/Router.php');
   $router=new Router();
   //controller/methode=>UC
   $router->getRoute();
   /*
   $sec=new Security();
   $sec->showPage();
   $obj->{$method}()
   */
<!DOCTYPE html>
<html>

<head>

    <title>GESCO</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="assets/bootstrap4/css/bootstrap.css">
    <link rel="stylesheet" href="style1.css">

</head>

<body>
    <div class="mainContainer">
        <div class="headerContainer">
            <div>
                <img src="Images/Icônes/logo.PNG" alt="image" class="img1">
                <h2 class="h2">Le plaisir de jouer </h2>
            </div>

        </div>
        <div class="bodyContainer">
            <div class="card form1 formJoueur">
                <div class="card-header ">
                    <h3 class="creation">CREER ET PARAMETRER VOS QUIZZ</h3>
                    <button type="submit" class="btn">Déconnexion</button>
                </div>
                <div class="card-body">
                    <div>
                        <div class="divLeft">
                            <div class="divLeft1"><img src="Images/Icônes/avatar.png" width="80px">
                                <p class="para1">AAA </p>
                                <p class="para2">BBB</p>
                            </div>
                            <div class="divLeft3">
                                Liste Questions
                                <img src="Images/Icônes/ic-liste-active.png" width="20px" class="image">
                            </div>
                            <div class="divLeft2">
                                <div class="greenDiv"></div>Créer Admin<img src="Images/Icônes/ic-ajout.png"
                                    width="20px" class="image">
                            </div>
                            <div class="divLeft4">Liste joueur<img src="Images/Icônes/ic-liste.png" width="20px"
                                    class="image">
                            </div>
                            <div class="divLeft5">Créer Question<img src="Images/Icônes/ic-ajout.png" width="20px"
                                    class="image">
                            </div>
                        </div>
                        <div class="inscription">
                            <p class="">Nbre de question/jeu</p>
                            <div class="form-group form-check col-12">
                                <input type="text" class="form-check-input"
                                    style="width:50px ; height:20px; margin-top:-35px ;margin-left:150px"
                                    id="exampleCheck1">

                            </div>
                            <button type="button" class="btn btn-primary text-center"
                                style="width:30px ; height:20px ; margin-top:-50px; margin-right:100px">ok</button>

                            <p style="margin-top:-25px">1. Les langages Web</p>
                            <ul style="margin-top:-25px">
                                <li>HTML</li>
                                <li>R</li>
                                <li>Java</li>
                            </ul>
                            <p style="margin-top:-25px">2. . D’où vient le Corona?</p>
                            <ul style="margin-top:-25px">
                                <li>Italie</li>
                                <li>R</li>

                            </ul>
                            <p style="margin-top:-25px">3. Quel terme définit langage qui s'adapte sur Androï et Ios</p>
                            <br>
                            <input type="text" class="form-check-input"
                                style="width:100px ; height:30px ;margin-top:-55px ; margin-left:60px"
                                id="exampleCheck1">

                            <p style="margin-top:-25px">4. Quelle est la première école de codage gratuite au Sénégal?
                            </p>
                            <ul style="margin-top:-25px">
                                <li>Simplon</li>
                                <li>Orange Digital Center</li>

                            </ul>
                            <p style="margin-top:-25px">5. Les précurseurs de la révolution digitale?</p>
                            <ul style="margin-top:-25px">
                                <li>GAFAM</li>
                                <li>CIA-FBI</li>

                            </ul>
                            <button type="button" class="btn btn-primary"
                                style="width:100px ; height:30px">Suivant</button>



                        </div>
                    </div>
                </div>
            </div>
            <script src="assets/jquery/jquery.js"></script>
            <script src="assets/bootstrap4/js/bootstrap.js"></script>
</body>

</html>
<!DOCTYPE html>
<html>

<head>

    <title>GESCO</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="assets/bootstrap4/css/bootstrap.css">
    <link rel="stylesheet" href="style1.css">

</head>

<body>
    <div class="mainContainer">
        <div class="headerContainer">
            <div>
                <img src="Images/Icônes/logo.PNG" alt="image" class="img1">
                <h2 class="h2">Le plaisir de jouer </h2>
            </div>

        </div>
        <div class="bodyContainer">
            <div class="card form1 formJoueur">
                <div class="card-header ">
                    <h3 class="creation">CREER ET PARAMETRER VOS QUIZZ</h3>
                    <button type="submit" class="btn">Déconnexion</button>
                </div>
                <div class="card-body">
                    <div>
                        <div class="divLeft">
                            <div class="divLeft1"><img src="Images/Icônes/avatar.png" width="80px">
                                <p class="para1">AAA </p>
                                <p class="para2">BBB</p>
                            </div>

                            <div class="divLeft3">
                                <nav class="nav flex-column py-3 ">
                                    <a class="nav-link " href="#">Lister Admin</a>
                                    <a class="nav-link" href="#">Créer Admin</a>
                                    <a class="nav-link" href="./../jeu/listerJoueur.php">Liste joueur</a>
                                    <a class="nav-link active" href="./../views/question/add_question.php">Creer
                                        Question</a>
                                </nav>
                            </div>
                        </div>
                        <div class="inscription">
                            <form>
                                <div class="form-group row">
                                    <label for="colFormLabelLg"
                                        class="col-sm-2 col-form-label col-form-label-sm">Question</label>
                                    <div class="col-sm-10">
                                        <input type="email" class="form-control form-control-lg " id="colFormLabelLg"
                                            placeholder="">
                                    </div>
                                </div>

                                <label class="my-1 mr-2" for="inlineFormCustomSelectPref">Nbre de points</label>
                                <select class="custom-select my-0.5 mr-sm-2 " style=" width:100px" id="point"
                                    name="point">

                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                </select>
                                <div class="form-group">
                                    <label for="inputPassword6">Type de réponse</label>


                                    <select id="typeReponse" style="width:250px" class="form-control mx-sm-2"
                                        name="typeReponse">
                                        <option>Réponse avec une seule réponse possible</option>
                                        <option>Réponse avec une seule réponse possible</option>
                                    </select>

                                    <img src="Images/Icônes/ic-ajout-réponse.png" width="20px" style="margin-top:-60px"
                                        class="image ">
                                </div>
                                <div class="form-group row">
                                    <label for="colFormLabelLg"
                                        class="col-sm-2 col-form-label col-form-label-sm">Réponse1</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control " id="reponse" placeholder=""
                                            width="20px" style="width:200px" name="reponse">
                                        <input type="checkbox" aria-label="Checkbox for following text input"
                                            class="checkbox1" style="  margin-left:230px ; margin-top:-90px"
                                            name="checkbox" id="checkbox" name="checkbox"><br>
                                        <input class="form-check-input" type="radio" name="gridRadios" id="radio"
                                            value="option3" style="margin-top:-65px ; margin-left:250px" name="radio">

                                    </div>
                                </div>





                                <img src="Images/Icônes/ic-supprimer.png" width="20px" class="image"
                                    style="margin-top:-140px ; margin-left:350px">
                                <button type="button" class="btn btn-primary">Enrégistrer</button>


                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <script src="assets/jquery/jquery.js"></script>
            <script src="assets/bootstrap4/js/bootstrap.js"></script>
</body>

</html>
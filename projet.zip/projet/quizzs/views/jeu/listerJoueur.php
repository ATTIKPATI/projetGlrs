<!DOCTYPE html>
<html>

<head>

    <title>GESCO</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="assets/bootstrap4/css/bootstrap.css">
    <link rel="stylesheet" href="style1.css">

</head>

<body>
    <div class="mainContainer">
        <div class="headerContainer">
            <div>
                <img src="Images/Icônes/logo.PNG" alt="image" class="img1">
                <h2 class="h2">Le plaisir de jouer </h2>
            </div>

        </div>
        <div class="bodyContainer">
            <div class="card form1 formJoueur">
                <div class="card-header ">
                    <h3 class="creation">CREER ET PARAMETRER VOS QUIZZ</h3>
                    <button type="submit" class="btn">Déconnexion</button>
                </div>
                <div class="card-body">
                    <div>
                        <div class="divLeft">
                            <div class="divLeft1"><img src="Images/Icônes/avatar.png" width="80px">
                                <p class="para1">AAA </p>
                                <p class="para2">BBB</p>
                            </div>

                            <nav class="nav flex-column py-3 ">
                                <a class="nav-link " href="#">Lister Admin</a>
                                <a class="nav-link" href="./../jeu/jeu.php">Jouer</a>
                                <a class="nav-link" href="./../jeu/listerJoueur.php">Liste joueur</a>
                                <a class="nav-link active" href="./../question/add_question.php">Creer
                                    Question</a>
                            </nav>
                        </div>
                        <div class="inscription">
                            <p>Listes des joueurs par score</p>
                            <div> Aucun joueur n'existe</div>

                        </div>
                    </div>
                </div>
            </div>
            <script src="assets/jquery/jquery.js"></script>
            <script src="assets/bootstrap4/js/bootstrap.js"></script>
</body>

</html>